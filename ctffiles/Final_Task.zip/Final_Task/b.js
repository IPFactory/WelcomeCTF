onload=_=>{E=V=>document.getElementById(V);S="春ですね3夏が来た3食欲の秋3冬は寒い3#fdd3#8b13#F903#8cf".split(N=3);E('t').onclick=_=>A(N=N^3?N+1:0);E('c').onclick=_=>A(N=N?N-1:3);A=_=>{E('g').src=N+".jpg",(M=E('m')).innerHTML=S[N],M.style.backgroundColor=S[N+4]}}
// welcomeCTF{Someday_you_will_see}
